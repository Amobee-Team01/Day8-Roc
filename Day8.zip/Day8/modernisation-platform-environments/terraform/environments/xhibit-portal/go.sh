export TF_VAR_LOCALMODE="true"
terraform plan
